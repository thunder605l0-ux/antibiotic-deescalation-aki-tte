# ============================================================================== 
# Analysis: Rebuild Supplementary Table 5 with ATO continuous-covariate variance ratios
# Date: 2026-08-30
# Random seed: not applicable (deterministic formatting of locked aggregate outputs)
# R: 4.4.2
# Key packages: flextable 0.9.11; officer 0.7.3
# Method: Recompute weighted variances directly from the 40 locked ATO weight
#         objects; no propensity-score, imputation, bootstrap, or outcome model
#         is refit.
# Purpose: Make the continuous-covariate variance-ratio diagnostic cited in the
#          Limitations directly verifiable and explicitly identify it as primary ATO.
# Source type: project locked RDS objects + self-written deterministic summary code
# Source name or URL: weights_anti_mrsa_imp01-20.rds;
#                     weights_anti_psa_imp01-20.rds; Supplementary Table 5
# Citation or commit/version: D-4.7N-ANALYSIS-LOCK-V2.0; D-4.6-ANALYSIS-OUTPUT-PLAN-V1.0
# Access date: 2026-08-30
# Adaptation notes: The weighted variance uses sum(w*(x-weighted_mean)^2)/sum(w),
#                   matching 22_rebuild_table1_jama_style_ato.R. The variance ratio
#                   is de-escalation divided by continuation and is summarised as
#                   the minimum-maximum range across 20 completed data sets.
# Verification command:
#   Rscript --vanilla
#   23_rebuild_supplementary_table5_variance_ratios_2026-08-27.R
# ============================================================================== 

options(stringsAsFactors = FALSE)
if (!requireNamespace("flextable", quietly = TRUE) || !requireNamespace("officer", quietly = TRUE)) {
  stop("Packages 'flextable' and 'officer' are required.")
}

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) != 1L) stop("Run this script with Rscript.")
script_path <- normalizePath(sub("^--file=", "", script_arg), winslash = "/", mustWork = TRUE)
project_root <- normalizePath(file.path(dirname(script_path), "..", "..", ".."), winslash = "/", mustWork = TRUE)
workspace_root <- normalizePath(file.path(project_root, ".."), winslash = "/", mustWork = TRUE)
data_dir <- file.path(project_root, "data")
weight_root <- file.path(workspace_root, "independent-R-runtime", "09_输出结果", "03_权重")
existing_st05_path <- file.path(data_dir, "Supplementary Table 5_Weighting Diagnostics.csv")
table1_path <- file.path(data_dir, "Table 1_Weighted Baseline Characteristics.csv")

atomic_write_csv <- function(data, path) {
  temporary_path <- paste0(path, ".tmp")
  utils::write.csv(data, temporary_path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
  if (file.exists(path)) unlink(path)
  if (!file.rename(temporary_path, path)) stop("Unable to atomically write: ", path)
}
atomic_write_docx <- function(document, path) {
  temporary_path <- paste0(path, ".tmp.docx")
  if (file.exists(temporary_path)) unlink(temporary_path)
  print(document, target = temporary_path)
  if (file.exists(path)) unlink(path)
  if (!file.rename(temporary_path, path)) stop("Unable to atomically write: ", path)
}

if (!dir.exists(weight_root) || !file.exists(existing_st05_path) || !file.exists(table1_path)) stop("Required locked diagnostic input is missing.")
panel_a_source <- utils::read.csv(existing_st05_path, check.names = FALSE, stringsAsFactors = FALSE)
table1 <- utils::read.csv(table1_path, check.names = FALSE, stringsAsFactors = FALSE)

# 仅从已发布的聚合表重取总体最大 SMD，保证与 Table 1 使用同一口径。
required_table1 <- c("Anti-MRSA: SMD", "Antipseudomonal: SMD")
if (length(setdiff(required_table1, names(table1))) > 0L) stop("Table 1 is missing SMD columns.")
max_smd <- vapply(required_table1, function(column) {
  values <- suppressWarnings(as.numeric(table1[[column]]))
  values[table1$Characteristic == "Microbiology status at T0"] <- NA_real_
  max(abs(values[is.finite(values)]))
}, numeric(1))
if (any(!is.finite(max_smd))) stop("Unable to recover maximum SMD from Table 1.")

panel_a_out <- panel_a_source[panel_a_source$Panel == "A. Overall weighting diagnostics", c("Panel", "Trial", "Characteristic", "Value", "Detail"), drop = FALSE]
if (nrow(panel_a_out) != 4L) stop("Supplementary Table 5 panel A is incomplete.")
for (trial in c("Anti-MRSA trial", "Antipseudomonal trial")) {
  row <- panel_a_out$Trial == trial & grepl("Overlap weighting", panel_a_out$Characteristic, fixed = TRUE)
  if (sum(row) != 1L) stop("Primary ATO row is not uniquely identified for ", trial)
  smd_name <- if (trial == "Anti-MRSA trial") "Anti-MRSA: SMD" else "Antipseudomonal: SMD"
  panel_a_out$Value[row] <- sprintf("%.3f", max_smd[[smd_name]])
  panel_a_out$Characteristic[row] <- "Overlap weighting (ATO; primary analysis; maximum |SMD| across 20 completed data sets)"
}

continuous_spec <- data.frame(
  field = c(
    "age_years", "baseline_creatinine_mg_dl",
    "target_antibiotic_administration_count_72h", "recent_nonrenal_sofa",
    "nonrenal_sofa_change", "creatinine_change_mg_dl",
    "urine_output_rate_6h_ml_kg_h"
  ),
  characteristic = c(
    "Age, y", "Baseline serum creatinine, mg/dL",
    "Target-antibiotic administrations during first 72 h",
    "Recent nonrenal SOFA score", "Change in nonrenal SOFA score",
    "Pre-index change in serum creatinine, mg/dL",
    "6-h urine-output rate, mL/kg/h"
  ),
  stringsAsFactors = FALSE
)
weighted_mean <- function(x, w) sum(x * w) / sum(w)
weighted_var <- function(x, w) {
  centre <- weighted_mean(x, w)
  sum(w * (x - centre)^2) / sum(w)
}
variance_ratio <- function(data, weights, field) {
  treatment <- as.integer(as.character(data$deescalation))
  x <- as.numeric(data[[field]])
  keep <- is.finite(x) & is.finite(weights) & weights > 0 & treatment %in% c(0L, 1L)
  x <- x[keep]
  weights <- weights[keep]
  treatment <- treatment[keep]
  weighted_var(x[treatment == 1L], weights[treatment == 1L]) /
    weighted_var(x[treatment == 0L], weights[treatment == 0L])
}
trial_map <- c(anti_mrsa = "Anti-MRSA trial", anti_psa = "Antipseudomonal trial")
panel_b_rows <- list()
audit_rows <- list()
row_index <- 0L
for (trial in names(trial_map)) {
  for (spec_index in seq_len(nrow(continuous_spec))) {
    ratios <- vapply(seq_len(20L), function(imputation) {
      object_path <- file.path(weight_root, sprintf("weights_%s_imp%02d.rds", trial, imputation))
      if (!file.exists(object_path)) stop("Missing locked ATO weight object: ", object_path)
      saved <- readRDS(object_path)
      if (!identical(saved$trial, trial) || saved$imputation != imputation) stop("Weight-object identity check failed: ", object_path)
      if (!continuous_spec$field[spec_index] %in% names(saved$completed_data)) stop("Missing continuous covariate in ", object_path)
      weights <- saved$ato_brlogit$weight
      if (length(weights) != nrow(saved$completed_data) || any(!is.finite(weights)) || any(weights <= 0)) stop("Invalid stored ATO weights in ", object_path)
      variance_ratio(saved$completed_data, weights, continuous_spec$field[spec_index])
    }, numeric(1))
    if (any(!is.finite(ratios))) stop("Non-finite ATO variance ratio for ", trial, ": ", continuous_spec$field[spec_index])
    row_index <- row_index + 1L
    lower <- min(ratios)
    upper <- max(ratios)
    panel_b_rows[[row_index]] <- data.frame(
      Trial = unname(trial_map[trial]),
      `Continuous covariate` = continuous_spec$characteristic[spec_index],
      `Variance-ratio range across 20 imputations` = sprintf("%.3f-%.3f", lower, upper),
      `Within 0.5–2.0 in all imputations` = ifelse(lower >= 0.5 && upper <= 2, "Yes", "No"),
      check.names = FALSE,
      stringsAsFactors = FALSE
    )
    audit_rows[[row_index]] <- data.frame(
      trial = trial,
      field = continuous_spec$field[spec_index],
      characteristic = continuous_spec$characteristic[spec_index],
      imputation = seq_len(20L),
      variance_ratio = ratios,
      stringsAsFactors = FALSE
    )
  }
}
panel_b <- do.call(rbind, panel_b_rows)
audit_detail <- do.call(rbind, audit_rows)

out_csv <- file.path(data_dir, "Supplementary Table 5_Weighting Diagnostics.csv")
out_docx <- file.path(data_dir, "Supplementary Table 5_Weighting Diagnostics.docx")
audit_csv <- file.path(data_dir, "Supplementary Table 5_Weighting Diagnostics_audit_2026-08-27.csv")
panel_b_out <- panel_b
panel_b_out$Panel <- "B. Continuous-covariate variance ratios after primary ATO"
combined_csv <- rbind(
  panel_a_out,
  data.frame(Panel = panel_b_out$Panel, Trial = panel_b_out$Trial, Characteristic = panel_b_out$`Continuous covariate`, Value = panel_b_out$`Variance-ratio range across 20 imputations`, Detail = panel_b_out$`Within 0.5–2.0 in all imputations`, stringsAsFactors = FALSE)
)
atomic_write_csv(combined_csv, out_csv)

ft_a <- flextable::flextable(panel_a_out)
ft_a <- flextable::theme_booktabs(ft_a)
ft_b <- flextable::flextable(panel_b)
ft_b <- flextable::theme_booktabs(ft_b)
for (name in c("ft_a", "ft_b")) {
  current <- get(name)
  current <- flextable::font(current, fontname = "Arial", part = "all")
  current <- flextable::fontsize(current, size = 8, part = "all")
  current <- flextable::valign(current, valign = "center", part = "all")
  current <- flextable::padding(current, padding.top = 2, padding.bottom = 2, padding.left = 3, padding.right = 3, part = "all")
  assign(name, current)
}
ft_a <- flextable::autofit(ft_a)
ft_b <- flextable::autofit(ft_b)
doc <- officer::read_docx()
doc <- officer::body_set_default_section(doc, officer::prop_section(page_size = officer::page_size(orient = "landscape"), page_margins = officer::page_mar(top = 0.55, bottom = 0.55, left = 0.55, right = 0.55)))
doc <- officer::body_add_par(doc, "Supplementary Table 5. Weighting Diagnostics for the Primary ATO Analysis", style = "Normal")
doc <- officer::body_add_par(doc, "A. Overall weighting diagnostics", style = "Normal")
doc <- flextable::body_add_flextable(doc, ft_a)
doc <- officer::body_add_par(doc, "B. Continuous-covariate variance ratios after primary overlap weighting", style = "Normal")
doc <- flextable::body_add_flextable(doc, ft_b)
note <- paste(
  "Abbreviations: ATO, average treatment effect in the overlap population; ESS, effective sample size; PS, propensity score; SMD, standardised mean difference.",
  "Panel A summarises the primary ATO and complementary CBPS-ATE diagnostics. Panel B reports the range of the weighted variance ratio (de-escalation divided by continuation) across 20 imputed data sets for every continuous covariate in the primary ATO analysis.",
  "The prespecified variance-ratio target was 0.5 to 2.0; a range outside that interval indicates residual distribution-shape imbalance despite a small SMD."
)
doc <- officer::body_add_fpar(doc, officer::fpar(officer::ftext(paste0("Note. ", note), officer::fp_text(font.family = "Arial", font.size = 8))))
atomic_write_docx(doc, out_docx)

weight_paths <- file.path(weight_root, sprintf(
  "weights_%s_imp%02d.rds",
  rep(c("anti_mrsa", "anti_psa"), each = 20L),
  rep(seq_len(20L), times = 2L)
))
audit_detail$estimand <- "ATO"
audit_detail$variance_definition <- "de-escalation weighted variance / continuation weighted variance"
audit_detail$weight_object <- basename(weight_paths)[match(
  paste(audit_detail$trial, audit_detail$imputation),
  paste(rep(c("anti_mrsa", "anti_psa"), each = 20L), rep(seq_len(20L), times = 2L))
)]
audit_detail$weight_object_md5 <- toupper(unname(tools::md5sum(file.path(weight_root, audit_detail$weight_object))))
atomic_write_csv(audit_detail, audit_csv)
cat("ST05_ESTIMAND=ATO\nST05_CONTINUOUS_COVARIATES=", nrow(panel_b), "\n", sep = "")
