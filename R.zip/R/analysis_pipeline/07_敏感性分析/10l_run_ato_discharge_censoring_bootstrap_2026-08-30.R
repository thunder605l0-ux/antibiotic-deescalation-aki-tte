# ==============================================================================
# Analysis: ATO sensitivity analysis treating live discharge as censoring
# Date: 2026-08-30
# Random seed: no new random sampling; reuses the 1000 locked bootstrap samples
#              and their completed MICE data sets (anti-PSA b=934 unavailable)
# R: 4.4.2
# Key packages: mice 3.17.0; WeightIt 1.4.0; brglm2 1.0.1;
#               cobalt 4.6.1; survival 3.8-3
#
# Method source:
#   Project-locked Boot-MI engine, 04_bootstrap_single_repeat.R
#   WeightIt commit 595d2812c2f4d56ff7c14aaf6fcde76c59aa8c8f
#   Li F, Morgan KL, Zaslavsky AM. JASA. 2018;113:390-400.
# Citation/version: D-4.7I-ATO-BRLOGIT-SENSITIVITY-PROTOCOL-V2.0;
#                   D-4.7N-ANALYSIS-LOCK-V2.0
# Access date: 2026-08-30
# Adaptation:
#   Within every existing bootstrap checkpoint, complete each of the 20 MICE
#   data sets, refit the locked br.logit ATO weights, and estimate the 7-day AKI
#   cumulative incidence by Aalen-Johansen with death before AKI as competing
#   and live discharge before AKI as censoring. Risks are averaged across the
#   20 completed data sets. Percentile intervals use R quantile type 7.
#   No bootstrap sample, imputation, outcome phenotype, or propensity-score
#   specification is regenerated or changed.
# Verification command:
#   $env:TTE_RUNTIME_ROOT='<your-R-runtime-root>'
#   $env:TTE_DISCHARGE_WORKERS='6'
#   Rscript --vanilla
#     10l_run_ato_discharge_censoring_bootstrap_2026-08-30.R
# ==============================================================================

options(stringsAsFactors = FALSE, warn = 1)

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) != 1L) stop("Run this analysis with Rscript.")
script_path <- normalizePath(sub("^--file=", "", script_arg), winslash = "/", mustWork = TRUE)
project_root <- normalizePath(file.path(dirname(script_path), "..", "..", ".."), winslash = "/", mustWork = TRUE)

runtime_root <- Sys.getenv("TTE_RUNTIME_ROOT", unset = "")
if (!nzchar(runtime_root)) {
  runtime_root <- file.path(dirname(project_root), "independent-R-runtime")
}
runtime_root <- normalizePath(runtime_root, winslash = "/", mustWork = TRUE)
engine_path <- file.path(runtime_root, "05_Bootstrap", "04_bootstrap_single_repeat.R")
checkpoint_dir <- file.path(runtime_root, "09_输出结果", "04_Bootstrap", "checkpoints")
weight_dir <- file.path(runtime_root, "09_输出结果", "03_权重")
output_dir <- file.path(project_root, "06_补充表", "06_敏感性分析", "controlled_reporting")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(engine_path) || !dir.exists(checkpoint_dir) || !dir.exists(weight_dir)) {
  stop("The locked Boot-MI engine, checkpoints, or ATO weight objects are missing.")
}

worker_count <- suppressWarnings(as.integer(Sys.getenv("TTE_DISCHARGE_WORKERS", unset = "4")))
if (!is.finite(worker_count) || worker_count < 1L) worker_count <- 1L
worker_count <- min(worker_count, max(1L, parallel::detectCores(logical = TRUE) - 1L))

source(engine_path, encoding = "UTF-8")

atomic_write_csv <- function(data, path) {
  temporary_path <- paste0(path, ".tmp")
  utils::write.csv(data, temporary_path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
  if (file.exists(path)) unlink(path)
  if (!file.rename(temporary_path, path)) stop("Unable to atomically write: ", path)
}

make_discharge_censoring_event <- function(data) {
  aki <- as.integer(as.character(data$aki_7d))
  competing <- as.character(data$aki_competing_state)
  if (anyNA(aki) || anyNA(competing)) stop("Fixed AKI outcome fields contain missing values.")
  factor(
    ifelse(
      aki == 1L,
      "aki",
      ifelse(competing == "death_before_aki", "death_before_aki", "censor")
    ),
    levels = c("censor", "aki", "death_before_aki")
  )
}

estimate_two_strategy_risks <- function(data, weight, event_factor) {
  treatment <- as.integer(as.character(data$deescalation))
  if (!setequal(unique(treatment), c(0L, 1L))) stop("A completed data set lost one strategy group.")
  risks <- vapply(c(0L, 1L), function(strategy) {
    index <- treatment == strategy
    probability <- weighted_aj_boot(
      as.numeric(data$aki_followup_days[index]),
      event_factor[index],
      weight[index]
    )
    unname(probability["aki"])
  }, numeric(1))
  names(risks) <- c("risk_0", "risk_1")
  risks
}

process_checkpoint <- function(path) {
  checkpoint <- readRDS(path)
  if (!identical(checkpoint$status, "success")) stop("Non-success checkpoint: ", path)
  imputation_rows <- vector("list", mice_m)
  reproduction_error <- numeric(mice_m)
  locked_ato <- checkpoint$imputation_estimates[
    checkpoint$imputation_estimates$model == "ato",
    ,
    drop = FALSE
  ]
  locked_ato <- locked_ato[order(locked_ato$imputation), , drop = FALSE]
  if (nrow(locked_ato) != mice_m) stop("Locked ATO imputation estimates are incomplete: ", path)

  for (imputation_index in seq_len(mice_m)) {
    completed <- mice::complete(checkpoint$imputation, imputation_index)
    fitted <- fit_bootstrap_weights(completed, ps_formula_main, "ato")

    primary_event <- make_aki_event_factor_boot(completed$aki_7d, completed$aki_competing_state)
    primary_risks <- estimate_two_strategy_risks(completed, fitted$weight, primary_event)
    reproduction_error[imputation_index] <- max(abs(primary_risks - c(
      locked_ato$risk_aki_0[imputation_index],
      locked_ato$risk_aki_1[imputation_index]
    )))

    sensitivity_event <- make_discharge_censoring_event(completed)
    sensitivity_risks <- estimate_two_strategy_risks(completed, fitted$weight, sensitivity_event)
    imputation_rows[[imputation_index]] <- data.frame(
      imputation = imputation_index,
      risk_0 = sensitivity_risks["risk_0"],
      risk_1 = sensitivity_risks["risk_1"],
      stringsAsFactors = FALSE
    )
  }

  maximum_reproduction_error <- max(reproduction_error)
  if (!is.finite(maximum_reproduction_error) || maximum_reproduction_error > 1e-10) {
    stop("Primary ATO numerical regression check failed for ", basename(path),
         "; max error=", format(maximum_reproduction_error, scientific = TRUE))
  }

  imputation_results <- do.call(rbind, imputation_rows)
  pooled_risk_0 <- mean(imputation_results$risk_0)
  pooled_risk_1 <- mean(imputation_results$risk_1)
  data.frame(
    trial = checkpoint$trial,
    bootstrap_index = as.integer(checkpoint$bootstrap_index),
    checkpoint_file = basename(path),
    checkpoint_analysis_lock = as.character(checkpoint$analysis_lock),
    risk_0 = pooled_risk_0,
    risk_1 = pooled_risk_1,
    rd = pooled_risk_1 - pooled_risk_0,
    rr = pooled_risk_1 / pooled_risk_0,
    imputation_m = mice_m,
    maximum_primary_reproduction_error = maximum_reproduction_error,
    stringsAsFactors = FALSE
  )
}

checkpoint_registry <- list(
  anti_mrsa = file.path(checkpoint_dir, sprintf("anti_mrsa_b%04d_checkpoint.rds", seq_len(1000L))),
  anti_psa = file.path(checkpoint_dir, sprintf("anti_psa_b%04d_checkpoint.rds", seq_len(1000L)))
)
if (!all(file.exists(checkpoint_registry$anti_mrsa))) stop("Anti-MRSA does not have all 1000 checkpoints.")
missing_psa <- which(!file.exists(checkpoint_registry$anti_psa))
if (!identical(missing_psa, 934L)) stop("Unexpected anti-PSA missing checkpoints: ", paste(missing_psa, collapse = ","))
checkpoint_registry$anti_psa <- checkpoint_registry$anti_psa[-missing_psa]

all_paths <- unname(unlist(checkpoint_registry, use.names = FALSE))
replicate_path <- file.path(output_dir, "ST-08_ato_discharge_censoring_bootstrap_replicates_2026-08-30.csv")
reuse_replicates <- identical(
  tolower(Sys.getenv("TTE_DISCHARGE_REUSE_REPLICATES", unset = "false")),
  "true"
)
if (reuse_replicates && file.exists(replicate_path)) {
  replicates <- utils::read.csv(replicate_path, check.names = FALSE, stringsAsFactors = FALSE)
} else {
  if (worker_count == 1L) {
    replicate_list <- lapply(all_paths, process_checkpoint)
  } else {
    cluster <- parallel::makePSOCKcluster(worker_count)
    on.exit(parallel::stopCluster(cluster), add = TRUE)
    parallel::clusterExport(
      cluster,
      c("engine_path", "make_discharge_censoring_event", "estimate_two_strategy_risks", "process_checkpoint"),
      envir = environment()
    )
    parallel::clusterEvalQ(cluster, source(engine_path, encoding = "UTF-8"))
    replicate_list <- parallel::parLapplyLB(cluster, all_paths, process_checkpoint)
    parallel::stopCluster(cluster)
    on.exit(NULL, add = FALSE)
  }
  replicates <- do.call(rbind, replicate_list)
}

replicates <- replicates[order(replicates$trial, replicates$bootstrap_index), , drop = FALSE]
expected_counts <- c(anti_mrsa = 1000L, anti_psa = 999L)
actual_counts <- table(replicates$trial)
if (!identical(as.integer(actual_counts[names(expected_counts)]), unname(expected_counts))) {
  stop("Unexpected successful replicate counts.")
}

estimate_original_sample <- function(trial) {
  rows <- lapply(seq_len(20L), function(imputation_index) {
    object_path <- file.path(weight_dir, sprintf("weights_%s_imp%02d.rds", trial, imputation_index))
    saved <- readRDS(object_path)
    if (!identical(saved$trial, trial) || saved$imputation != imputation_index) {
      stop("Original-sample weight-object identity check failed: ", object_path)
    }
    event <- make_discharge_censoring_event(saved$completed_data)
    risks <- estimate_two_strategy_risks(saved$completed_data, saved$ato_brlogit$weight, event)
    data.frame(imputation = imputation_index, risk_0 = risks[1], risk_1 = risks[2])
  })
  rows <- do.call(rbind, rows)
  risks <- colMeans(rows[, c("risk_0", "risk_1")])
  c(
    risk_0 = unname(risks["risk_0"]),
    risk_1 = unname(risks["risk_1"]),
    rd = unname(risks["risk_1"] - risks["risk_0"]),
    rr = unname(risks["risk_1"] / risks["risk_0"])
  )
}

point_estimates <- lapply(names(expected_counts), function(trial) {
  estimate <- estimate_original_sample(trial)
  data.frame(
    trial = trial,
    specification = "discharge_as_censoring",
    estimand = "ATO",
    risk_0 = unname(estimate["risk_0"]),
    risk_1 = unname(estimate["risk_1"]),
    rd = unname(estimate["rd"]),
    rr = unname(estimate["rr"]),
    stringsAsFactors = FALSE
  )
})
point_estimates <- do.call(rbind, point_estimates)

summary_rows <- lapply(names(expected_counts), function(trial) {
  current <- replicates[replicates$trial == trial, , drop = FALSE]
  point <- point_estimates[point_estimates$trial == trial, , drop = FALSE]
  rd_interval <- stats::quantile(current$rd, c(0.025, 0.5, 0.975), names = FALSE, type = 7)
  rr_interval <- stats::quantile(current$rr, c(0.025, 0.5, 0.975), names = FALSE, type = 7)
  data.frame(
    trial = trial,
    specification = "discharge_as_censoring",
    estimand = "ATO",
    weight_model = "overlap_weight_brlogit",
    bootstrap_B = nrow(current),
    risk_0 = point$risk_0,
    risk_1 = point$risk_1,
    rd_point_estimate = point$rd,
    rd_ci_lower = rd_interval[1],
    rd_bootstrap_median = rd_interval[2],
    rd_ci_upper = rd_interval[3],
    rr_point_estimate = point$rr,
    rr_ci_lower = rr_interval[1],
    rr_bootstrap_median = rr_interval[2],
    rr_ci_upper = rr_interval[3],
    imputation_m = 20L,
    percentile_quantile_type = 7L,
    live_discharge_handling = "censoring",
    death_before_aki_handling = "competing event",
    stringsAsFactors = FALSE
  )
})
summary_table <- do.call(rbind, summary_rows)

point_path <- file.path(output_dir, "ST-08_ato_discharge_censoring_point_estimates_2026-08-30.csv")
summary_path <- file.path(output_dir, "ST-08_ato_discharge_censoring_results_2026-08-30.csv")
atomic_write_csv(replicates, replicate_path)
atomic_write_csv(point_estimates, point_path)
atomic_write_csv(summary_table, summary_path)

manifest <- c(
  "# ATO live-discharge-censoring sensitivity outputs",
  "",
  "Generated: 2026-08-30",
  "Method: locked Boot-MI checkpoints; 20 completed data sets per checkpoint; refitted br.logit ATO weights; death competing; live discharge censored; type-7 percentile intervals.",
  paste0("Engine: `", engine_path, "`"),
  paste0("Checkpoint directory: `", checkpoint_dir, "`"),
  paste0("Workers: ", worker_count),
  "",
  "## Outputs",
  paste0("- `", basename(replicate_path), "` — one row per successful bootstrap replicate"),
  paste0("- `", basename(point_path), "` — original-sample point estimates from 20 locked ATO weight objects"),
  paste0("- `", basename(summary_path), "` — point estimates and 95% type-7 percentile intervals"),
  "",
  paste0("Anti-MRSA successful replicates: ", expected_counts["anti_mrsa"]),
  paste0("Anti-PSA successful replicates: ", expected_counts["anti_psa"], " (b=934 excluded because the locked imputation failed)"),
  paste0("Maximum primary-result numerical regression error: ", format(max(replicates$maximum_primary_reproduction_error), scientific = TRUE))
)
writeLines(manifest, file.path(output_dir, "_analysis_outputs_ato_discharge_censoring_2026-08-30.md"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "sessionInfo_ato_discharge_censoring_2026-08-30.txt"), useBytes = TRUE)

print(summary_table)
cat("ATO_DISCHARGE_CENSORING_BOOTSTRAP_COMPLETE=TRUE\n")
