# ==============================================================================
# Analysis: Exploratory drug-subgroup ATO estimates for 7-day AKI
# Date: 2026-08-30
# Random seed: no new random sampling; reuses the locked bootstrap samples and
#              their completed MICE data sets (anti-PSA b=934 unavailable)
# R: 4.4.2
# Key packages: mice 3.17.0; WeightIt 1.4.0; brglm2 1.0.1; survival 3.8-3
#
# Code source:
#   Project-locked Boot-MI engine, 04_bootstrap_single_repeat.R
# Citation/version: D-4.7N-ANALYSIS-LOCK-V2.0
# Access date: 2026-08-30
# Adaptation:
#   In each locked bootstrap sample, the main br.logit ATO model is refitted in
#   every one of 20 completed data sets. Its full-trial overlap weights are then
#   restricted to the fixed initial-drug subgroup, exactly matching the existing
#   exploratory point-estimate definition. Weighted Aalen-Johansen risks retain
#   death and live discharge before AKI as competing events. Risks are averaged
#   across imputations before calculating the subgroup risk difference.
#   Confidence intervals are type-7 percentile intervals.
# Verification command:
#   $env:TTE_RUNTIME_ROOT='<your-R-runtime-root>'
#   $env:TTE_DRUG_SUBGROUP_WORKERS='6'
#   Rscript --vanilla
#     10m_run_ato_drug_subgroup_bootstrap_2026-08-30.R
# ==============================================================================

options(stringsAsFactors = FALSE, warn = 1)

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) != 1L) stop("Run this analysis with Rscript.")
script_path <- normalizePath(sub("^--file=", "", script_arg), winslash = "/", mustWork = TRUE)
project_root <- normalizePath(file.path(dirname(script_path), "..", "..", ".."), winslash = "/", mustWork = TRUE)

runtime_root <- Sys.getenv("TTE_RUNTIME_ROOT", unset = "")
if (!nzchar(runtime_root)) runtime_root <- file.path(dirname(project_root), "independent-R-runtime")
runtime_root <- normalizePath(runtime_root, winslash = "/", mustWork = TRUE)
engine_path <- file.path(runtime_root, "05_Bootstrap", "04_bootstrap_single_repeat.R")
checkpoint_dir <- file.path(runtime_root, "09_输出结果", "04_Bootstrap", "checkpoints")
weight_dir <- file.path(runtime_root, "09_输出结果", "03_权重")
output_dir <- file.path(project_root, "06_补充表", "06_敏感性分析", "controlled_reporting")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(engine_path) || !dir.exists(checkpoint_dir) || !dir.exists(weight_dir)) {
  stop("The locked Boot-MI engine, checkpoints, or ATO weight objects are missing.")
}

worker_count <- suppressWarnings(as.integer(Sys.getenv("TTE_DRUG_SUBGROUP_WORKERS", unset = "4")))
if (!is.finite(worker_count) || worker_count < 1L) worker_count <- 1L
worker_count <- min(worker_count, max(1L, parallel::detectCores(logical = TRUE) - 1L))

source(engine_path, encoding = "UTF-8")

atomic_write_csv <- function(data, path) {
  temporary_path <- paste0(path, ".tmp")
  utils::write.csv(data, temporary_path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
  if (file.exists(path)) unlink(path)
  if (!file.rename(temporary_path, path)) stop("Unable to atomically write: ", path)
}

read_drug_registry <- function(trial) {
  filename <- if (trial == "anti_mrsa") "final.data_anti-MRSA.csv" else "final.data_anti-PSA.csv"
  data <- utils::read.csv(file.path(project_root, "final_data", filename), check.names = FALSE)
  if (anyDuplicated(data$icu_stay_id)) stop("Duplicate ICU stay identifiers in ", filename)
  code <- as.character(data$initial_target_antibiotic)
  if (anyNA(code) || any(!nzchar(code))) stop("Missing initial-drug code in ", filename)
  setNames(code, as.character(data$icu_stay_id))
}

drug_registry <- list(
  anti_mrsa = read_drug_registry("anti_mrsa"),
  anti_psa = read_drug_registry("anti_psa")
)

subgroup_definitions <- list(
  anti_mrsa = list(
    vancomycin = function(code) code == "15"
  ),
  anti_psa = list(
    without_piperacillin_tazobactam = function(code) code != "13",
    with_piperacillin_tazobactam = function(code) code == "13"
  )
)

estimate_subgroup_risks <- function(data, weight, event_factor, subgroup) {
  treatment <- as.integer(as.character(data$deescalation))
  risks <- vapply(c(0L, 1L), function(strategy) {
    index <- subgroup & treatment == strategy
    if (sum(index) < 2L) stop("A bootstrap subgroup lost a treatment strategy.")
    unname(weighted_aj_boot(
      as.numeric(data$aki_followup_days[index]),
      event_factor[index],
      weight[index]
    )["aki"])
  }, numeric(1))
  names(risks) <- c("risk_0", "risk_1")
  risks
}

process_checkpoint <- function(path) {
  checkpoint <- readRDS(path)
  if (!identical(checkpoint$status, "success")) stop("Non-success checkpoint: ", path)
  trial <- checkpoint$trial
  source_id <- as.character(checkpoint$source_icu_stay_id)
  drug_code <- drug_registry[[trial]][source_id]
  if (length(drug_code) != length(source_id) || anyNA(drug_code)) {
    stop("Initial-drug mapping failed: ", basename(path))
  }

  locked_ato <- checkpoint$imputation_estimates[
    checkpoint$imputation_estimates$model == "ato", , drop = FALSE
  ]
  locked_ato <- locked_ato[order(locked_ato$imputation), , drop = FALSE]
  if (nrow(locked_ato) != mice_m) stop("Locked ATO imputation estimates are incomplete: ", path)

  subgroup_names <- names(subgroup_definitions[[trial]])
  imputation_rows <- vector("list", mice_m)
  reproduction_error <- numeric(mice_m)
  for (imputation_index in seq_len(mice_m)) {
    completed <- mice::complete(checkpoint$imputation, imputation_index)
    fitted <- fit_bootstrap_weights(completed, ps_formula_main, "ato")
    event <- make_aki_event_factor_boot(completed$aki_7d, completed$aki_competing_state)

    primary_risks <- estimate_subgroup_risks(completed, fitted$weight, event, rep(TRUE, nrow(completed)))
    reproduction_error[imputation_index] <- max(abs(primary_risks - c(
      locked_ato$risk_aki_0[imputation_index], locked_ato$risk_aki_1[imputation_index]
    )))

    current_rows <- lapply(subgroup_names, function(subgroup_name) {
      subgroup <- subgroup_definitions[[trial]][[subgroup_name]](drug_code)
      risks <- estimate_subgroup_risks(completed, fitted$weight, event, subgroup)
      data.frame(
        imputation = imputation_index,
        subgroup = subgroup_name,
        risk_0 = unname(risks["risk_0"]),
        risk_1 = unname(risks["risk_1"]),
        stringsAsFactors = FALSE
      )
    })
    imputation_rows[[imputation_index]] <- do.call(rbind, current_rows)
  }

  maximum_reproduction_error <- max(reproduction_error)
  if (!is.finite(maximum_reproduction_error) || maximum_reproduction_error > 1e-10) {
    stop("Primary ATO numerical regression check failed for ", basename(path),
         "; max error=", format(maximum_reproduction_error, scientific = TRUE))
  }

  imputation_results <- do.call(rbind, imputation_rows)
  pooled <- lapply(subgroup_names, function(subgroup_name) {
    current <- imputation_results[imputation_results$subgroup == subgroup_name, , drop = FALSE]
    risk_0 <- mean(current$risk_0)
    risk_1 <- mean(current$risk_1)
    data.frame(
      trial = trial,
      bootstrap_index = as.integer(checkpoint$bootstrap_index),
      subgroup = subgroup_name,
      risk_0 = risk_0,
      risk_1 = risk_1,
      rd = risk_1 - risk_0,
      imputation_m = mice_m,
      maximum_primary_reproduction_error = maximum_reproduction_error,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, pooled)
}

checkpoint_registry <- list(
  anti_mrsa = file.path(checkpoint_dir, sprintf("anti_mrsa_b%04d_checkpoint.rds", seq_len(1000L))),
  anti_psa = file.path(checkpoint_dir, sprintf("anti_psa_b%04d_checkpoint.rds", seq_len(1000L)))
)
if (!all(file.exists(checkpoint_registry$anti_mrsa))) stop("Anti-MRSA does not have all 1000 checkpoints.")
missing_psa <- which(!file.exists(checkpoint_registry$anti_psa))
if (!identical(missing_psa, 934L)) stop("Unexpected anti-PSA missing checkpoints: ", paste(missing_psa, collapse = ","))
checkpoint_registry$anti_psa <- checkpoint_registry$anti_psa[-missing_psa]
all_paths <- unname(unlist(checkpoint_registry, use.names = FALSE))

replicate_path <- file.path(output_dir, "ST-11_ato_drug_subgroup_bootstrap_replicates_2026-08-30.csv")
reuse_replicates <- identical(tolower(Sys.getenv("TTE_DRUG_SUBGROUP_REUSE_REPLICATES", unset = "false")), "true")
if (reuse_replicates && file.exists(replicate_path)) {
  replicates <- utils::read.csv(replicate_path, check.names = FALSE, stringsAsFactors = FALSE)
} else {
  if (worker_count == 1L) {
    replicate_list <- lapply(all_paths, process_checkpoint)
  } else {
    cluster <- parallel::makePSOCKcluster(worker_count)
    on.exit(parallel::stopCluster(cluster), add = TRUE)
    parallel::clusterExport(
      cluster,
      c("engine_path", "drug_registry", "subgroup_definitions", "estimate_subgroup_risks", "process_checkpoint"),
      envir = environment()
    )
    parallel::clusterEvalQ(cluster, source(engine_path, encoding = "UTF-8"))
    replicate_list <- parallel::parLapplyLB(cluster, all_paths, process_checkpoint)
    parallel::stopCluster(cluster)
    on.exit(NULL, add = FALSE)
  }
  replicates <- do.call(rbind, replicate_list)
}

replicates <- replicates[order(replicates$trial, replicates$subgroup, replicates$bootstrap_index), , drop = FALSE]
expected_counts <- c(
  "anti_mrsa|vancomycin" = 1000L,
  "anti_psa|without_piperacillin_tazobactam" = 999L,
  "anti_psa|with_piperacillin_tazobactam" = 999L
)
actual_counts <- table(paste(replicates$trial, replicates$subgroup, sep = "|"))
if (!identical(as.integer(actual_counts[names(expected_counts)]), unname(expected_counts))) {
  stop("Unexpected successful subgroup replicate counts.")
}

estimate_original_sample <- function(trial, subgroup_name) {
  rows <- lapply(seq_len(20L), function(imputation_index) {
    saved <- readRDS(file.path(weight_dir, sprintf("weights_%s_imp%02d.rds", trial, imputation_index)))
    completed <- saved$completed_data
    source_id <- as.character(saved$key_map$icu_stay_id)
    drug_code <- drug_registry[[trial]][source_id]
    if (anyNA(drug_code)) stop("Original-sample initial-drug mapping failed.")
    subgroup <- subgroup_definitions[[trial]][[subgroup_name]](drug_code)
    event <- make_aki_event_factor_boot(completed$aki_7d, completed$aki_competing_state)
    risks <- estimate_subgroup_risks(completed, saved$ato_brlogit$weight, event, subgroup)
    data.frame(risk_0 = unname(risks["risk_0"]), risk_1 = unname(risks["risk_1"]))
  })
  risks <- colMeans(do.call(rbind, rows))
  c(risk_0 = unname(risks["risk_0"]), risk_1 = unname(risks["risk_1"]),
    rd = unname(risks["risk_1"] - risks["risk_0"]))
}

point_keys <- strsplit(names(expected_counts), "\\|", fixed = FALSE)
point_estimates <- do.call(rbind, lapply(point_keys, function(key) {
  estimate <- estimate_original_sample(key[1], key[2])
  data.frame(
    trial = key[1], subgroup = key[2], estimand = "ATO exploratory subgroup",
    risk_0 = unname(estimate["risk_0"]), risk_1 = unname(estimate["risk_1"]),
    rd = unname(estimate["rd"]), stringsAsFactors = FALSE
  )
}))

stopifnot(
  identical(round(point_estimates$rd, 3), c(-0.008, -0.071, -0.068)),
  identical(round(point_estimates$risk_0, 3), c(0.320, 0.211, 0.293)),
  identical(round(point_estimates$risk_1, 3), c(0.312, 0.140, 0.225))
)

summary_table <- do.call(rbind, lapply(seq_len(nrow(point_estimates)), function(index) {
  point <- point_estimates[index, , drop = FALSE]
  current <- replicates[replicates$trial == point$trial & replicates$subgroup == point$subgroup, , drop = FALSE]
  interval <- stats::quantile(current$rd, c(0.025, 0.5, 0.975), names = FALSE, type = 7)
  data.frame(
    trial = point$trial, subgroup = point$subgroup, estimand = point$estimand,
    weight_model = "full-trial overlap_weight_brlogit restricted to subgroup",
    bootstrap_B = nrow(current), risk_0 = point$risk_0, risk_1 = point$risk_1,
    rd_point_estimate = point$rd, rd_ci_lower = interval[1],
    rd_bootstrap_median = interval[2], rd_ci_upper = interval[3],
    imputation_m = 20L, percentile_quantile_type = 7L,
    death_before_aki_handling = "competing event",
    live_discharge_handling = "competing event", stringsAsFactors = FALSE
  )
}))

point_path <- file.path(output_dir, "ST-11_ato_drug_subgroup_point_estimates_2026-08-30.csv")
summary_path <- file.path(output_dir, "ST-11_ato_drug_subgroup_results_2026-08-30.csv")
atomic_write_csv(replicates, replicate_path)
atomic_write_csv(point_estimates, point_path)
atomic_write_csv(summary_table, summary_path)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "sessionInfo_ato_drug_subgroup_2026-08-30.txt"), useBytes = TRUE)

cat("ATO_DRUG_SUBGROUP_BOOTSTRAP_COMPLETE\n")
print(summary_table)
cat("MAX_PRIMARY_REPRO_ERROR=", format(max(replicates$maximum_primary_reproduction_error), scientific = TRUE), "\n", sep = "")
