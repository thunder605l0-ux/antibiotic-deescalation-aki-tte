# ==============================================================================
# 分析：将既有 AKI 敏感性分析改为主要 ATO 估计目标。
# 日期：2026-09-07；R 4.4.2；随机抽样和插补沿用原检查点，不生成新随机样本。
# 来源：10_run_sensitivity_analyses.R、10k_repair_ato_mortality_sensitivity_2026-08-26.R。
# 引用/commit：WeightIt 595d2812c2f4d56ff7c14aaf6fcde76c59aa8c8f；
# mice 61083e667fa41cc4bc655492591b100bf8a7e443；访问日期：2026-09-07。
# 适配：四项规格复用既有 ATO AKI 逐次结果；两项 AKI 定义复用原 Bootstrap/MICE，
#       用主分析 br.logit 重叠权重重新估计；风险先跨20份插补平均，再计算 RD/RR。
# 验证命令：Rscript --vanilla 10n_repair_ato_aki_sensitivity_2026-09-07.R
#           --trial=anti_mrsa --start=1 --end=1 --preflight=true
# ==============================================================================
options(stringsAsFactors = FALSE, warn = 1)
arg <- function(key, default) {
  value <- grep(paste0('^--', key, '='), commandArgs(TRUE), value = TRUE)
  if (!length(value)) return(default)
  stopifnot(length(value) == 1L)
  sub(paste0('^--', key, '='), '', value)
}
script_path <- normalizePath(sub('^--file=', '', grep('^--file=', commandArgs(FALSE), value=TRUE)), winslash='/')
# 公开版路径由调用者配置，不再搜索作者内部目录。
project <- Sys.getenv('TTE_PROJECT_ROOT', unset='')
if (!nzchar(project)) stop('Set TTE_PROJECT_ROOT; see README.md.')
project <- normalizePath(project, winslash='/', mustWork=TRUE)
locked_path <- file.path(dirname(script_path), '10_run_sensitivity_analyses.R')
lines <- readLines(locked_path, encoding='UTF-8', warn=FALSE)
boundary <- which(trimws(lines) == 'replicate_rows <- list()')
stopifnot(length(boundary) == 1L)
# 仅加载原规格与结局函数，原 ATE 驱动程序不执行。
eval(parse(text=lines[seq_len(boundary-1L)]), envir=.GlobalEnv)
set.seed(master_seed)
ato_brglm_retry_maxit <- 2000L
original_fit <- fit_bootstrap_weights
fit_bootstrap_weights <- function(data, formula, model) {
  stopifnot(model == 'cbps_ate')
  original_fit(data=data, formula=formula, model='ato')
}
specs <- c('aki_cross_t0_uo_boundary', 'creatinine_only_phenotype')
trial <- arg('trial', 'anti_mrsa')
stopifnot(trial %in% trial_registry$trial)
start <- as.integer(arg('start','1'))
end <- as.integer(arg('end','1000'))
preflight <- identical(arg('preflight','false'),'true')
out <- Sys.getenv('TTE_ATO_AKI_OUTPUT', unset=file.path(output_root,'06_敏感性分析','ato_aki_repair_20260907'))
dir.create(out,recursive=TRUE,showWarnings=FALSE)
repeat_dir <- file.path(out,'repeats')
dir.create(repeat_dir,showWarnings=FALSE)
raw_path <- file.path(data_dir,paste0('analysis_dataset_',trial,'.csv'))
raw <- read.csv(raw_path,check.names=FALSE)
submission_root <- Sys.getenv('TTE_SUBMISSION_ROOT', unset=file.path(project,'final_data'))
submission_path <- file.path(submission_root,if(trial=='anti_mrsa') 'final.data_anti-MRSA.csv' else 'final.data_anti-PSA.csv')
if (!file.exists(submission_path)) stop('Missing submission dataset for version validation: ',submission_path)
stopifnot(isTRUE(all.equal(raw,read.csv(submission_path,check.names=FALSE))))
raw <- augment_creatinine_only_outcome(raw,trial)
old_dir <- file.path(output_root,'06_敏感性分析','ato_mortality_repair_20260826','full')
old_reps <- read.csv(file.path(old_dir,'ST-08_ato_mortality_sensitivity_bootstrap_replicates.csv'))
old_points <- read.csv(file.path(old_dir,'ST-08_ato_mortality_sensitivity_point_estimates.csv'))
expected <- if(trial=='anti_mrsa') seq_len(1000L) else setdiff(seq_len(1000L),934L)
for (sp in c('NEW_MS03','ABX_TIME_proxy','MICRO_STATE_proxy','complete_case')) {
  d <- old_reps[old_reps$trial==trial & old_reps$specification==sp,]
  stopifnot(nrow(d)==length(expected),setequal(d$bootstrap_index,expected),all(d$estimand=='ATO'))
  stopifnot(max(abs(d$rd_aki-(d$risk_aki_1-d$risk_aki_0)))<1e-12)
}
validate <- function(d) {
  stopifnot(nrow(d)==2L,all(d$estimand=='ATO'),setequal(d$specification,specs))
  stopifnot(all(is.finite(as.matrix(d[,c('risk_aki_0','risk_aki_1','rd_aki','rr_aki')]))))
  stopifnot(all(d$risk_aki_0>=0 & d$risk_aki_0<=1),all(d$risk_aki_1>=0 & d$risk_aki_1<=1))
  stopifnot(max(abs(d$rd_aki-(d$risk_aki_1-d$risk_aki_0)))<1e-12)
}
calculate <- function(cp,b) {
  stopifnot(cp$imputation$m==20L,cp$imputation$iteration==50L)
  if(b>0L) stopifnot(identical(as.character(cp$source_icu_stay_id),as.character(raw$icu_stay_id[cp$sampled_row])))
  do.call(rbind,lapply(specs,function(sp) {
    est <- estimate_specification(cp,raw,trial,sp)
    data.frame(trial=trial,bootstrap_index=b,specification=sp,estimand='ATO',weight_model='overlap_weight_brlogit',as.list(est))
  }))
}
if(start==1L) {
  mid <- readRDS(file.path(output_root,'02_MICE',paste0('mids_',trial,'_m20_maxit50.rds')))
  cp <- list(sampled_row=seq_len(nrow(raw)),imputation=mid$imputation,mice_seed=master_seed)
  points <- calculate(cp,0L)
  validate(points)
  write.csv(points,file.path(out,paste0(trial,'_points.csv')),row.names=FALSE)
}
indices <- intersect(seq.int(start,end),expected)
for(b in indices) {
  target <- file.path(repeat_dir,sprintf('%s_b%04d.rds',trial,b))
  if(file.exists(target)) {validate(readRDS(target)); next}
  cp_path <- file.path(checkpoint_dir,sprintf('%s_b%04d_checkpoint.rds',trial,b))
  cp <- readRDS(cp_path)
  stopifnot(cp$status=='success',cp$trial==trial,cp$bootstrap_index==b)
  if(preflight) {
    primary <- estimate_specification(cp,raw,trial,'death_calendar_boundary')
    old <- old_reps[old_reps$trial==trial & old_reps$bootstrap_index==b & old_reps$specification=='death_calendar_boundary',]
    stopifnot(nrow(old)==1L,max(abs(as.numeric(primary[c('risk_aki_0','risk_aki_1','rd_aki')])-as.numeric(old[1,c('risk_aki_0','risk_aki_1','rd_aki')])))<1e-10)
    message('PRIMARY_ATO_REPRODUCTION_PASS trial=',trial,' b=',b)
  }
  result <- tryCatch(calculate(cp,b),error=function(e) {
    saveRDS(list(trial=trial,b=b,error=conditionMessage(e),checkpoint_md5=unname(tools::md5sum(cp_path))),file.path(out,sprintf('%s_b%04d_failure.rds',trial,b)))
    stop(e)
  })
  validate(result)
  attr(result,'checkpoint_md5') <- unname(tools::md5sum(cp_path))
  saveRDS(result,target,version=3)
  message('ATO_AKI_PROGRESS trial=',trial,' b=',b,' time=',Sys.time())
}
writeLines(capture.output(sessionInfo()),file.path(out,paste0(trial,'_',start,'_sessionInfo.txt')))
message('ATO_AKI_CHUNK_COMPLETE trial=',trial,' start=',start,' end=',end)
