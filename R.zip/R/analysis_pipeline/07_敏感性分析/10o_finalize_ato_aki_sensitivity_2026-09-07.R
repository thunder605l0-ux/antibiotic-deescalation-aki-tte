# 分析：汇总修正后的ATO AKI敏感性分析，原抽样与插补保持不变。
# 来源：10n_repair_ato_aki_sensitivity_2026-09-07.R；10k_repair_ato_mortality_sensitivity_2026-08-26.R。
# 引用/版本：R 4.4.2 stats::quantile(type=7)；访问日期：2026-09-07。
# 适配：合并六项规格及原主ATO估计；逐次审计重复编号、风险、RD/RR和检查点哈希。
# 验证命令：Rscript --vanilla 10o_finalize_ato_aki_sensitivity_2026-09-07.R
options(stringsAsFactors=FALSE)
script <- normalizePath(sub('^--file=','',grep('^--file=',commandArgs(FALSE),value=TRUE)),winslash='/')
arg <- function(key, default) {
  values <- grep(paste0('^--',key,'='),commandArgs(TRUE),value=TRUE)
  if (!length(values)) return(default)
  stopifnot(length(values)==1L)
  sub(paste0('^--',key,'='),'',values)
}
# 公开复核模式仅读取已保存的逐次汇总风险，不含患者数据，也不重新拟合模型。
# 来源：R 4.4.2 stats::quantile(type=7)；访问日期：2026-09-07。
# 适配：重算全部百分位数区间，与投稿数值逐项比较；无随机抽样。
# 验证命令：Rscript --vanilla 10o_finalize_ato_aki_sensitivity_2026-09-07.R --mode=archived
mode <- arg('mode','archived')
stopifnot(mode %in% c('archived','checkpoints'))
if (mode=='archived') {
  archive <- file.path(dirname(dirname(dirname(script))),'analysis_results','ato_aki_sensitivity_20260907')
  reference <- read.csv(file.path(archive,'ATO_AKI_sensitivity_results.csv'))
  audited <- reference
  for (trial in unique(reference$trial)) {
    d <- read.csv(file.path(archive,paste0(trial,'_all_replicates.csv')))
    expected <- if(trial=='anti_mrsa') 1:1000 else setdiff(1:1000,934L)
    for (sp in unique(reference$specification)) {
      v <- d[d$specification==sp,]
      stopifnot(nrow(v)==length(expected),!anyDuplicated(v$bootstrap_index),setequal(v$bootstrap_index,expected))
      stopifnot(all(is.finite(as.matrix(v[,c('risk_aki_0','risk_aki_1','rd_aki','rr_aki')]))))
      stopifnot(all(v$risk_aki_0>=0 & v$risk_aki_0<=1),all(v$risk_aki_1>=0 & v$risk_aki_1<=1))
      stopifnot(max(abs(v$rd_aki-v$risk_aki_1+v$risk_aki_0))<1e-12,max(abs(v$rr_aki-v$risk_aki_1/v$risk_aki_0))<1e-10)
      for (metric in c('risk_aki_0','risk_aki_1','rd_aki','rr_aki')) {
        ix <- which(reference$trial==trial & reference$specification==sp & reference$metric==metric)
        stopifnot(length(ix)==1L,reference$bootstrap_success_n[ix]==nrow(v))
        ci <- quantile(v[[metric]],c(.025,.975),type=7,names=FALSE)
        stopifnot(max(abs(ci-as.numeric(reference[ix,c('ci_lower','ci_upper')])))<1e-10)
        audited[ix,c('ci_lower','ci_upper')] <- ci
      }
    }
    # 原样本两项表型点估计与提交汇总表一致。
    pts <- read.csv(file.path(archive,paste0(trial,'_points.csv')))
    for (j in seq_len(nrow(pts))) for(metric in c('risk_aki_0','risk_aki_1','rd_aki','rr_aki')) {
      ix <- which(reference$trial==trial & reference$specification==pts$specification[j] & reference$metric==metric)
      stopifnot(length(ix)==1L,abs(reference$estimate[ix]-pts[[metric]][j])<1e-10)
    }
  }
  dest <- arg('output',file.path(tempdir(),'ATO_AKI_sensitivity_recomputed.csv'))
  stopifnot(normalizePath(dirname(dest),mustWork=TRUE)!=normalizePath(archive,mustWork=TRUE))
  write.csv(audited,dest,row.names=FALSE)
  print(audited[audited$metric=='rd_aki' & audited$specification=='creatinine_only_phenotype',],row.names=FALSE)
  cat('ARCHIVED_REPLICATE_CI_VALIDATION=PASS\nOutput: ',dest,'\n',sep='')
  quit(save='no',status=0L)
}
# 完整检查点模式的根目录均由环境变量提供，沿用原分析算法。
runtime <- Sys.getenv('TTE_RUNTIME_ROOT',unset='')
if (!nzchar(runtime)) stop('Set TTE_RUNTIME_ROOT for checkpoint mode; see README.md.')
runtime_output <- Sys.getenv('TTE_OUTPUT_ROOT',unset=file.path(runtime,'09_输出结果'))
out <- Sys.getenv('TTE_ATO_AKI_OUTPUT',unset=file.path(runtime_output,'06_敏感性分析','ato_aki_repair_20260907'))
old <- file.path(runtime_output,'06_敏感性分析','ato_mortality_repair_20260826','full')
reps <- read.csv(file.path(old,'ST-08_ato_mortality_sensitivity_bootstrap_replicates.csv'))
pts <- read.csv(file.path(old,'ST-08_ato_mortality_sensitivity_point_estimates.csv'))
specs <- c('death_calendar_boundary','aki_cross_t0_uo_boundary','creatinine_only_phenotype','NEW_MS03','ABX_TIME_proxy','MICRO_STATE_proxy','complete_case')
fields <- c('trial','specification','risk_aki_0','risk_aki_1','rd_aki','rr_aki')
records <- list(); points <- list(); hashes <- list()
for(trial in c('anti_mrsa','anti_psa')) {
  indices <- if(trial=='anti_mrsa') 1:1000 else setdiff(1:1000,934)
  paths <- file.path(out,'repeats',sprintf('%s_b%04d.rds',trial,indices))
  stopifnot(all(file.exists(paths)))
  new <- lapply(seq_along(paths),function(i) {
    d <- readRDS(paths[i])
    stopifnot(nrow(d)==2L,all(d$bootstrap_index==indices[i]),all(d$trial==trial),all(d$estimand=='ATO'))
    cp <- file.path(runtime_output,'04_Bootstrap','checkpoints',sprintf('%s_b%04d_checkpoint.rds',trial,indices[i]))
    stopifnot(identical(attr(d,'checkpoint_md5'),unname(tools::md5sum(cp))))
    d[,c(fields,'bootstrap_index')]
  })
  d <- rbind(reps[reps$trial==trial,c(fields,'bootstrap_index')],do.call(rbind,new))
  p <- rbind(pts[pts$trial==trial,fields],read.csv(file.path(out,paste0(trial,'_points.csv')))[,fields])
  for(sp in specs) {
    v <- d[d$specification==sp,]
    stopifnot(nrow(v)==length(indices),!anyDuplicated(v$bootstrap_index),setequal(v$bootstrap_index,indices))
    stopifnot(all(is.finite(as.matrix(v[,fields[3:6]]))),all(v$risk_aki_0>=0 & v$risk_aki_0<=1),all(v$risk_aki_1>=0 & v$risk_aki_1<=1))
    stopifnot(max(abs(v$rd_aki-v$risk_aki_1+v$risk_aki_0))<1e-12,max(abs(v$rr_aki-v$risk_aki_1/v$risk_aki_0))<1e-10)
    q <- p[p$specification==sp,]; stopifnot(nrow(q)==1L)
    for(metric in fields[3:6]) {
      ci <- quantile(v[[metric]],c(.025,.975),type=7,names=FALSE)
      records[[length(records)+1L]] <- data.frame(trial=trial,specification=sp,estimand='ATO',metric=metric,estimate=q[[metric]],ci_lower=ci[1],ci_upper=ci[2],bootstrap_success_n=nrow(v))
    }
  }
  write.csv(d,file.path(out,paste0(trial,'_all_replicates.csv')),row.names=FALSE)
}
result <- do.call(rbind,records)
write.csv(result,file.path(out,'ATO_AKI_sensitivity_results.csv'),row.names=FALSE)
inputs <- c(script,file.path(dirname(script),'10n_repair_ato_aki_sensitivity_2026-09-07.R'),list.files(old,pattern='(point_estimates|bootstrap_replicates|provenance).csv$',full.names=TRUE))
stopifnot(requireNamespace('digest',quietly=TRUE))
write.csv(data.frame(path=inputs,sha256=vapply(inputs,function(p) digest::digest(file=p,algo='sha256'),character(1))),file.path(out,'input_sha256.csv'),row.names=FALSE)
print(result[result$metric=='rd_aki',],row.names=FALSE)
cat('ALL_REPLICATE_AND_CHECKPOINT_VALIDATION=PASS\n')
