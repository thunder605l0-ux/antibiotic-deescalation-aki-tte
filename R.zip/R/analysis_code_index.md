# Analysis code and prespecified analysis plan index

**Manuscript:** "Immediate discontinuation versus continuation of empirical broad-spectrum coverage in ICU sepsis without prior acute kidney injury: a MIMIC-IV target trial emulation for anti-MRSA and antipseudomonal strategies" (BMC Infectious Diseases)

**Purpose.** This index documents the locked analysis plan, its dated outcome-blind estimand amendment, and the core analysis scripts underpinning the reported results. SHA-256 hashes support reproducibility; inclusion in this index does not by itself imply that every post-lock repair or exploratory analysis was prespecified. This repository contains the complete analysis chain from the locked plan through sensitivity, exploratory, and presentation scripts. Cohort-construction SQL and one-time diagnostic probes are not required to reproduce the reported results and remain in the authors internal audit archive; hashes of indexed internal-only scripts are retained below for audit completeness.

**Submission-file note.** The final manuscript uses Table S1-S11 and Figure S1-S8 as reader-facing labels. Submission filenames begin with `Additional file`, followed by the Table S/Figure S label and a short content description. The locked ST/SF identifiers used by scripts and analysis outputs are unchanged. The current filename mapping is documented in `README.md`.

## Prespecified analysis plan

| File | Role | SHA-256 |
|---|---|---|
| `analysis_plan_locked.md` | Locked statistical analysis plan | `E84090E038359DACC1150CF576B5AFBA6A2A66B66621F7896871C85E58E788AD` |
| `analysis_output_plan_locked.md` | Locked analysis output plan | `49ED0442D4887C2B717D536AA00655E803E5D386E3E40C734AA042148CC3EDEA` |
| `method_locked.md` | Locked method specification | `2BE762E56B681D518B6BF5D3FEF48D9B3F571D74148BD1485D155802E530B083` |

The dated record distinguishes the original full-population CBPS-ATE specification from the subsequent outcome-blind reporting amendment: ATO is the primary reporting estimand and CBPS-ATE is complementary. It also records version history (v1.0–v1.5, locked 2026-07-28/29), the input dataset SHA-256, imputation specification (m=20, maxit=50, PMM donors=5), the nested-bootstrap contract (1000 resamples, imputation repeated within each resample), and the failure-handling protocol.

## Core analysis scripts (SHA-256)

Scripts are grouped by analysis stage in execution order. All analyses were performed in R 4.4.2; package versions and commit identifiers are recorded in each script header citation block and summarised in `R_script_manifest.csv`.


**Coverage note.** The following indexed scripts are part of the locked audit trail but are not required to reproduce the reported results, and are therefore not included in this public archive: one-time diagnostic and convergence-investigation probes (`02a`, `03b`, `05a`-`05g`, `06a`, `10b`, `10e`-`10j`, `12`), superseded workflow versions (`06`, `07`, `07c`), and the internal DAG-structure revision script (`67_phase34_external_review_batch03_dual_dag_revision.R`). Their SHA-256 hashes above refer to the internal audit archive.

### 研究设计与DAG

| File | SHA-256 |
|---|---|
| `67_phase34_external_review_batch03_dual_dag_revision.R` | `00AE77F26EA88642E525AA75A179F582095CF68562BD7BB0691C6103C97047D8` |

### 配置与变量字典

| File | SHA-256 |
|---|---|
| `21_build_publication_display_dictionary.R` | `2A0A30A1622F4788E76E6BE9FAAFFE00A2BDBDD49C0F7BC9972B12F8F02BF12E` |
| `analysis_config.R` | `B83B7E6A91A6ADCB88117AD28AD63B7CE3EB53E7F7E1ED6445ABC2DE52E661E1` |
| `mice_imputation_extensions.R` | `994DCDBD5D449015617C09D598A5444F3250E6BA5BC5C34AEE74D8B95D3D04C2` |
| `publication_style_helpers.R` | `A027088CAEB38CCC9CF5C80C20F81BC8600D91C1729E559F6891577A66A6BF71` |

### 多重插补

| File | SHA-256 |
|---|---|
| `02_run_multiple_imputation.R` | `7C207B97B13E5F1BF00265246131F65CFC6A678843B41E41FC205EB54278AF30` |
| `02a_mice_diagnostic_outputs.R` | `87B38DCA11393DB1948D790501C1EF65D2B8874C84991C1FDF959516763AEE05` |
| `02b_mice_chain_diagnostics_controlled.R` | `85378FF4D390585602E9F7F017E8ECC4AFAB6C0992CF003EB00BA4BF0DD03077` |

### 倾向评分与权重

| File | SHA-256 |
|---|---|
| `03_fit_cbps_ate_weights.R` | `BE41A43EC2288C380FFEE7C12F56DD7381637255FC82C6BB31E7726E30E2ABE3` |
| `03a_weight_diagnostic_outputs.R` | `F4D492D3047C04591B78F4AACFE5F8F16F42DE37D18D57CC9B65B0700486DD81` |
| `03b_weight_diagnostic_figures_controlled.R` | `07B17C73DC33CECCDE2124D8D5A8613FED076EDB5E4495ECF7761FAA6AF07995` |

### Bootstrap

| File | SHA-256 |
|---|---|
| `04_bootstrap_core_locked.R` | `37F262872464299BA15F8ABE5CB5CDE3DD897DB7B0238F025DA8A7749598055B` |
| `04_bootstrap_single_repeat.R` | `5DD3A60F94D476AC21BEEAE9848EE378999D1410577939CB706EF9BDA848BAD7` |
| `05_run_bootstrap.R` | `E13D0A3C63B9E77B4ED1913AFFCC60E169C136B766DC686D43C5072F768E9E27` |
| `05a_diagnose_mice_logged_events.R` | `B8F4D33552AF534E4FDA6CDAB3BAEE6EFCBBB73497E68F46A2C57E27CC35803F` |
| `05b_diagnose_ato_brglm_nonconvergence.R` | `16F7A2A6E290164B99310CF31517622C82E838EDB676B96D552632D1DF866EAA` |
| `05c_diagnose_logreg100_nonconvergence.R` | `450838067E70E91BD8302D7D7914BF9E287F3A4EECB892C8D1C109A1813B147C` |
| `05d_diagnose_source_control_logreg_nonconvergence.R` | `6E5A3EAD3652C3D7EDA237030CCAFF9DDD645A3A210B14A8C5F96E8A819E4D23` |
| `05e_validate_bootstrap_checkpoints.R` | `FE077D0C917700F2F11724CCCB46CE83701913ADEE4A658264B5AAC66D398524` |
| `05f_diagnose_logreg_equivalent_solver.R` | `4BA55C81F646B54BE8A7DA249330555B69799CC0DB9EA6D6AD67102405B09F17` |
| `05g_diagnose_logreg_same_likelihood_solver.R` | `0AD851F409D1DB554DCAB45CD0F7E6A546FDB8C653AF14C2E523349A6FDE9810` |
| `06_pool_bootstrap_results.R` | `72B7DAB9514958657BE12D8EF51462DF7EA7890051C4D36F8EC0C1687D5E95E5` |
| `06a_rank_sensitivity_one_missing.R` | `2795DAB55034600DC0BC244DB74F95B146D4E780E9EFE954A47B2FF0869F604E` |
| `06b_pool_bootstrap_results_controlled.R` | `B9A427E8C5BD4992ADD2CC360FE7CF6B19C1636EA0D9E79C162BCA7EDF56CC7C` |

### 主要结局分析

| File | SHA-256 |
|---|---|
| `07_primary_outcome_tables.R` | `32B5FAB6647C5F3DCAFF290368DC9768707599576CD9BB6194B66E57D82854B7` |
| `07b_primary_outcome_tables_controlled.R` | `923F3516F9FD19CCF5F1C7D86A0E369C46B7E5FDFA93055F5EE160F0C9B36B85` |
| `07c_format_primary_outcome_docx_landscape.R` | `AA700C1898F5FAEE06A9BAF78C96E271C1C790CC8E1A919C7BC4A928DC5BD94A` |

### 敏感性分析

| File | SHA-256 |
|---|---|
| `10_run_sensitivity_analyses.R` | `8851F55B4E1439852C79D84E71B532A689378D30DEC2F05E396C6FFE8F9DBE4E` |
| `10b_run_sensitivity_analyses_controlled.R` | `661E8342802FABD7E380EC0727D106A68CE7D0252774E603A0F0D463CD5903ED` |
| `10c_run_sensitivity_analyses_controlled_v2.R` | `3CDC269DFFF2F9B3F32A99D94536FB662829A669B43D4C1C76A0136F61C91E6F` |
| `10d_finalize_sensitivity_analyses_controlled_v2.R` | `D11B87E67F56AEDC5648F6293C46E61362F23EAC22DAD9F6D2281453E7D3F714` |
| `10e_diagnose_st08_new_ms03_controlled_v2.R` | `77DCD9398CC8FA75D0D3061B61A7B74148F223DA53C53DD2647B63989C004918` |
| `10f_diagnose_st08_cbps_nonconvergence_controlled_v2.R` | `DE55C8D085CD9185083FEED696A9E1B45471A47561AFCC62EB99C72B21A3E7E2` |
| `10g_validate_st08_cbps_extension_controlled_v2.R` | `8C10811238DFC75B3C430495D6E5D8AFC917F3F99AAB48ABC83898EC3BD51A6C` |
| `10h_diagnose_st08_logreg100_nonconvergence_controlled_v2.R` | `6123E1D0367F2F199F005D9912BE0C9341209AEFE70CBA88B5AD7F51526A2F5F` |
| `10i_diagnose_st08_zero_rr_boundary_controlled_v2.R` | `5E7B15D8DD088E0EF00A80B6AF00C17DE7DFDD600451F5E474A4E9AB4186B350` |
| `10j_diagnose_st08_b0635_event_routing_controlled_v2.R` | `FFD616C131EE3C66BE67E55BB6E226E7851423421382969F05189526C04837C3` |
| `10l_run_ato_discharge_censoring_bootstrap_2026-08-30.R` | `ECAA0867CB2C3A667BC88B0ACF2B501113BA0102C0A8950705F96A240039393E` |
| `10m_run_ato_drug_subgroup_bootstrap_2026-08-30.R` | `0C7B873C3A71C8E2382B8E75A7407480696C11CF636F4284B852C20C67CE0581` |
| `12_unmeasured_confounding_evalue.R` | `C3B646273974C3DEB6E6E618C1E1842108DB46D17BD291970E7BC0278494973B` |
| `12b_rebuild_ato_evalues_all_primary_outcomes_2026-08-27.R` | `0452206A1871DAF0D3BBA3A5FC9F4BAEA39CE472A5AA681C2233D6CDEE1BCED4` |
| `13_aki_phenotype_components.R` | `BB9821D3A05F5F948E2A5CA8D14F135020CA3DDB73EDF107A3FBC9CC4C8F42B2` |

`10l` and `10m` are dated reproducibility repairs completed after the original lock. They reuse the locked patient-level bootstrap samples and completed imputation objects; they are not represented as prespecified analyses. Script `12_unmeasured_confounding_evalue.R` is retained only to reproduce the historical complementary CBPS-ATE E-values; the current primary ATO E-values are generated by `12b_rebuild_ato_evalues_all_primary_outcomes_2026-08-27.R`.

### 共享参与者探索性分析

| File | SHA-256 |
|---|---|
| `23_joint_strategy_crossclassification_2026-08-28.R` | `98AFAAE57548703121D0937478254AA21FA326A431A5DCF72F7D0517775EE200` |

该脚本位于 `analysis_pipeline/09_探索性分析/`，从两份锁定试验分析数据重建共享 171 人的 2×2 策略交叉表；输出为未加权描述性风险及 Clopper–Pearson 精确区间，不调用主分析权重或 bootstrap。

### 运行入口与数据校验

| File | SHA-256 |
|---|---|
| `01_validate_input_data.R` | `C61D0E6849B1E271553695E33D27B587F709A96E203EC59B5A0C9130BCCD3B2E` |

### ATO AKI 敏感性分析（2026-09-07 修订链）

| File | SHA-256 |
|---|---|
| `10k_repair_ato_mortality_sensitivity_2026-08-26.R` | `518E881A818AA12EE04ABD26CB94B7B4A61808F79D3ED414680898EC282FE570` |
| `10n_repair_ato_aki_sensitivity_2026-09-07.R` | `CA3ECA432D9FAA2E7DBA3387FECBE1D4C9E33A21A424A7CE30F06B177BC069E8` |
| `10o_finalize_ato_aki_sensitivity_2026-09-07.R` | `7839A71CB2F3E6405632558A442C5EE18FE27D640DDEBDF018982659C21B6B11` |

### 发表表与图脚本

| File | SHA-256 |
|---|---|
| `14_target_trial_mapping_table.R` | `44C82A181774C6A846145F84F85EADCF8480804A5D3A710B8CBFB102DA0E04EA` |
| `15_antibacterial_dictionary_table.R` | `14475F21ED382DD91EFE44290BCB382C8C308B8B60292E443EACE07A5FA0BF48` |
| `16_variable_definition_table.R` | `5B3849B6B5E69C14F71914D78019891B2FCFEE3D04460518FEB932E93F78FD2B` |
| `17_complete_nonsensitivity_outputs_controlled.R` | `BA044A425A62ACDB4063D679D3865B14CAD47A4C949910B99E462209932A3BB0` |
| `20a_generate_publication_tables_en.R` | `0B95F7F6E8481DD1309EF09D5178DC69F981FE22060B15FA04DAEE625E5D29E9` |
| `20b_generate_publication_figures_en.R` | `98914C91958B8331E2FF38C6988EDCE5F9B475FED5990B2A8DB028AAA97DD995` |
| `20c_validate_publication_ready_outputs_en.R` | `419312962245A89172D46D2A80790018676817C16DDF364C0B1B9E0D619F9A7A` |
| `21_rebuild_mf01_compact_nature_2026-08-28.R` | `781CE07101C2934F09B616D88C7468A3E5317B24B73E1E79ACB2C0EFBCFD24C9` |
| `22_rebuild_table1_jama_style_ato.R` | `7B3CC82FAEC9AE3E4EDCEC3E7E85FCDE63E46CB53BEEA936814939A5628891B7` |
| `22_repair_table1_ato_microbiology_2026-08-28.R` | `D48C20163177F772A0BCF35A5A7D48216A4885678015B1FBF818E9A54845C9BF` |
| `23_rebuild_supplementary_table5_variance_ratios_2026-08-27.R` | `5CC64945A747AC399B169C13855D549774CE82632BFAC8D8642E00FDE9626D93` |
| `plot_bmc_compliance_figures.R` | `22197B01D4176ED5E24575E3724D3CE9708EDE211C8B2DFD3EAD30774C9560FA` |
| `plot_english_dual_dag.R` | `811D758CA5AB0F411DC822717A013EBE9BCE7B5FE07EC2D1A395867AA47BD040` |
| `plot_figure2_aki_curve_ato.R` | `9FA33A310A85769AFAAE3CED686CB5260189D1DB13924274785A12C4A6E592E1` |
| `plot_figure3_death_curve.R` | `AA9FA44B77E914062571B88FBB905402A331911C2D1A9BCE579D1FDBAEE9BC92` |
| `plot_main_findings.R` | `4C525BD543C36F650511956A3BCC9F11EAC2FA3E9576A1F6D12C48135178C927` |
| `plot_primary_ato_diagnostics_2026-08-20.R` | `087C5C026930E99A69F05135387312F9A3D3CA3C1687D374E56003137E79D365` |
| `plot_refined_supplementary_figures_2_4_8_3.R` | `017340B8ED50DE552A2D2A75724106BA9286104020BE896F507C5494B53A6497` |


## Notes

- **Cohort construction (SQL):** The complete SQL cohort-construction and blinded raw-extraction scripts are maintained in the authors internal audit archive (36 SQL scripts; not required to reproduce the reported analyses); the analysis input dataset SHA-256 is recorded in the locked plan.
- **Presentation scripts:** Figure and table generation scripts are included in this repository (`final_figure_scripts/` and `analysis_pipeline/08_supplementary_outputs/`).
- **Verification:** The hashes above can be recomputed with `sha256sum` / `Get-FileHash` to confirm that the reported results derive from the locked scripts.


## ATO AKI sensitivity-analysis correction, 2026-09-07

Four existing ATO AKI bootstrap result sets were reused. Two AKI phenotype specifications were recalculated using the original bootstrap samples and MICE objects. The finalized results include 1,000 anti-MRSA and 999 antipseudomonal replicates; original antipseudomonal replicate 934 remains unavailable. Results and provenance are in `analysis_results/ato_aki_sensitivity_20260907/`.

| File | SHA-256 |
|---|---|
| `10n_repair_ato_aki_sensitivity_2026-09-07.R` | `CA3ECA432D9FAA2E7DBA3387FECBE1D4C9E33A21A424A7CE30F06B177BC069E8` |
| `10o_finalize_ato_aki_sensitivity_2026-09-07.R` | `7839A71CB2F3E6405632558A442C5EE18FE27D640DDEBDF018982659C21B6B11` |


## Public portability and result verification, 2026-09-07

The three locked MICE configuration CSVs are included in `analysis_pipeline/02_配置与变量字典/`. Public scripts 10n and 10o use configurable runtime paths. Script 10o also provides an aggregate-only verification mode without patient data. Its archived mode validated all reported type-7 intervals. For each trial, 10n reproduced the original-sample phenotype estimates and checkpoint 1 results to tolerance 1e-10. Full patient-level reruns require the authorized inputs and original derived objects listed in README.md. Current public-script hashes differ from the historical execution-script hashes in `analysis_results/ato_aki_sensitivity_20260907/input_sha256.csv`; that file is retained as provenance of the original execution.
