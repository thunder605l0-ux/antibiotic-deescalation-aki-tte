# ============================================================
# Figure 4：初始抗假单胞菌药物探索性分层的表格化森林图
# 点估计与95%区间来自正式药物分层 Boot-MI 结果，本脚本不重算统计量。
# 代码来源：10m_run_ato_drug_subgroup_bootstrap_2026-08-30.R。
# 引用/commit：D-4.7N-ANALYSIS-LOCK-V2.0；当前项目非 Git 仓库，无 commit ID。
# 访问日期：2026-09-01。
# 适配说明：将正式结果按投稿版式绘制为森林图；投稿图不在图内重复整体标题，样本量由Supplementary Table 10承载；不修改估计值。
# 验证命令：Rscript manuscript/plot_main_findings.R
# ============================================================
suppressMessages(library(ggplot2))
project_root <- normalizePath(Sys.getenv("TTE_PROJECT_ROOT", unset = "."), winslash = "/", mustWork = TRUE)
out_dir  <- file.path(project_root, "manuscript", "plot_new")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# Figure 4：药物分层（探索性，抗PSA 含/不含哌拉西林-他唑巴坦）— JAMA 风格森林图
# 正式值：完整试验 ATO 权重限制于药物层 + 竞争风险 AJ（20插补均值 + Bootstrap CI）
formal_results <- read.csv(file.path(
  project_root, "06_补充表", "06_敏感性分析", "controlled_reporting",
  "ST-11_ato_drug_subgroup_results_2026-08-30.csv"
), check.names = FALSE)
formal_results <- formal_results[
  formal_results$trial == "anti_psa",
  , drop = FALSE
]
formal_results <- formal_results[match(
  c("without_piperacillin_tazobactam", "with_piperacillin_tazobactam"),
  formal_results$subgroup
), , drop = FALSE]
stopifnot(nrow(formal_results) == 2L, !anyNA(formal_results$subgroup))

d5 <- data.frame(
  Stratum = c("Without piperacillin-tazobactam", "With piperacillin-tazobactam"),
  RD = formal_results$rd_point_estimate,
  lo = formal_results$rd_ci_lower,
  hi = formal_results$rd_ci_upper,
  Cont_n = c(212, 103), Deesc_n = c(35, 22),
  stringsAsFactors=FALSE)
d5$y <- c(2, 1)
d5$estimate_ci <- sprintf("%+.1f (%+.1f to %+.1f)", 100*d5$RD, 100*d5$lo, 100*d5$hi)

# 锁定值断言：防止展示层调整意外更改数字。
stopifnot(
  identical(round(d5$RD, 3), c(-0.071, -0.068)),
  identical(round(d5$lo, 3), c(-0.196, -0.269)),
  identical(round(d5$hi, 3), c(0.057, 0.109)),
  identical(d5$Cont_n, c(212, 103)),
  identical(d5$Deesc_n, c(35, 22))
)

header <- data.frame(
  x = 22.0, y = 2.54,
  label = "RD (95% CI), pp",
  stringsAsFactors = FALSE
)

p5 <- ggplot(d5, aes(y=y)) +
  geom_vline(xintercept=0, linetype="dashed", colour="#777777", linewidth=0.55) +
  geom_vline(xintercept=16.5, colour="#E1E1E1", linewidth=0.35) +
  geom_segment(aes(x=lo*100, xend=hi*100, yend=y), linewidth=0.9, colour="#3C5488") +
  geom_segment(aes(x=lo*100, xend=lo*100, y=y-0.09, yend=y+0.09), linewidth=0.75, colour="#3C5488") +
  geom_segment(aes(x=hi*100, xend=hi*100, y=y-0.09, yend=y+0.09), linewidth=0.75, colour="#3C5488") +
  geom_point(aes(x=RD*100), shape=21, size=4.0, stroke=0.65, fill="#3C5488", colour="white") +
  geom_text(aes(x=22.0, label=estimate_ci), hjust=0.5, size=3.7,
            family="serif", colour="#252525") +
  geom_text(data=header, aes(x=x, y=y, label=label), inherit.aes=FALSE,
            fontface="bold", size=3.25, family="serif", colour="#252525") +
  scale_y_continuous(
    breaks=c(2,1), labels=c("Without piperacillin-tazobactam", "With piperacillin-tazobactam"),
    limits=c(0.62,2.68), expand=expansion(mult=c(0,0))
  ) +
  scale_x_continuous(breaks=seq(-30,10,10), limits=c(-33,31.5), expand=expansion(mult=c(0,0))) +
  labs(x="7-day AKI risk difference, percentage points (de-escalation minus continuation)", y=NULL) +
  theme_classic(base_size=11.2, base_family="serif") +
  theme(
    panel.grid.major.x=element_line(colour="#E8E8E8", linewidth=0.32),
    panel.grid.major.y=element_blank(),
    axis.text.y=element_text(size=10.8, colour="#252525"),
    axis.text.x=element_text(size=9.5),
    axis.title.x=element_text(size=10.5, margin=margin(t=8)),
    plot.margin=margin(10, 18, 10, 10)
  )

audit_dir <- file.path(project_root, "04_主文图表", "09_tables")
dir.create(audit_dir, recursive=TRUE, showWarnings=FALSE)
write.csv(d5[c("Stratum","RD","lo","hi","Cont_n","Deesc_n","estimate_ci")],
          file.path(audit_dir,"MF-04_drug_stratification_display_data.csv"), row.names=FALSE)

ggsave(file.path(out_dir,"Figure4_drug_stratification_RD.png"), p5, width=10.675, height=3.5, dpi=320, bg="white")
ggsave(file.path(out_dir,"Figure4_drug_stratification_RD.pdf"), p5, width=10.675, height=3.5, device=grDevices::cairo_pdf)
ggsave(file.path(out_dir,"Figure4_drug_stratification_RD.tiff"), p5, width=10.675, height=3.5, dpi=600, bg="white", device=grDevices::tiff, compression="lzw")
cat("Figure 4（药物分层）已生成\n")
